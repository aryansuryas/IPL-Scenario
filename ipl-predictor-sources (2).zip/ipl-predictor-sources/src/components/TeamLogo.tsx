import { TEAMS } from "@/lib/ipl-data";

interface TeamLogoProps {
  teamId: string;
  size?: number;
  className?: string;
}

export function TeamLogo({ teamId, size = 36, className = "" }: TeamLogoProps) {
  const team = TEAMS[teamId];
  if (!team) return null;
  const initials = team.short;
  return (
    <div
      className={`flex items-center justify-center rounded-full font-bold text-white shrink-0 shadow-sm ring-2 ring-white ${className}`}
      style={{
        width: size,
        height: size,
        background: `linear-gradient(135deg, ${team.color} 0%, ${team.color}cc 100%)`,
        fontSize: size * 0.32,
        letterSpacing: "-0.02em",
      }}
      aria-label={team.name}
    >
      {initials}
    </div>
  );
}
