import { Trophy, TrendingUp, TrendingDown } from "lucide-react";
import { TeamLogo } from "./TeamLogo";
import { TEAMS, BASE_STATS, type Match } from "@/lib/ipl-data";

interface PointsTableProps {
  matches: Match[];
  predictions: Record<number, string | null>;
}

interface Row {
  id: string;
  played: number;
  won: number;
  lost: number;
  points: number;
  nrr: number;
}

function computeRows(matches: Match[], predictions: Record<number, string | null>): Row[] {
  const rows: Record<string, Row> = {};
  Object.keys(TEAMS).forEach((id) => {
    const b = BASE_STATS[id];
    rows[id] = { id, played: b.played, won: b.won, lost: b.lost, points: b.won * 2, nrr: b.nrr };
  });

  matches.forEach((m) => {
    const winner = predictions[m.id];
    if (!winner) return;
    const loser = winner === m.home ? m.away : m.home;
    rows[winner].played += 1;
    rows[winner].won += 1;
    rows[winner].points += 2;
    rows[loser].played += 1;
    rows[loser].lost += 1;
  });

  return Object.values(rows).sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    return b.nrr - a.nrr;
  });
}

export function PointsTable({ matches, predictions }: PointsTableProps) {
  const rows = computeRows(matches, predictions);

  return (
    <div className="rounded-2xl bg-card overflow-hidden" style={{ boxShadow: "var(--shadow-premium)" }}>
      {/* Header band */}
      <div
        className="px-6 py-5 flex items-center justify-between"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="h-10 w-10 rounded-xl flex items-center justify-center"
            style={{ background: "var(--gradient-gold)", boxShadow: "var(--shadow-gold)" }}
          >
            <Trophy className="h-5 w-5" style={{ color: "var(--gold-foreground)" }} />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight text-navy-foreground">Points Table</h2>
            <p className="text-xs text-navy-foreground/70">Live • Updates with your predictions</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur">
          <div className="h-2 w-2 rounded-full bg-qualify animate-pulse" />
          <span className="text-xs font-medium text-navy-foreground/90">Qualification Zone</span>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/60 text-muted-foreground text-xs uppercase tracking-wider">
              <th className="text-left font-semibold py-3 pl-6 pr-2 w-12">#</th>
              <th className="text-left font-semibold py-3 px-2">Team</th>
              <th className="text-center font-semibold py-3 px-2">P</th>
              <th className="text-center font-semibold py-3 px-2">W</th>
              <th className="text-center font-semibold py-3 px-2">L</th>
              <th className="text-center font-semibold py-3 px-2">NRR</th>
              <th className="text-right font-semibold py-3 pr-6 pl-2">Pts</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => {
              const team = TEAMS[row.id];
              const inTop4 = idx < 4;
              return (
                <tr
                  key={row.id}
                  className="border-t border-border/60 transition-colors hover:bg-accent/40"
                  style={inTop4 ? { background: "var(--gradient-qualify)", boxShadow: "var(--shadow-glow-qualify)" } : {}}
                >
                  <td className="py-3.5 pl-6 pr-2">
                    <span
                      className={`inline-flex items-center justify-center h-7 w-7 rounded-lg text-xs font-bold ${
                        inTop4 ? "text-qualify-foreground" : "text-muted-foreground bg-muted"
                      }`}
                      style={inTop4 ? { background: "oklch(0.85 0.12 155 / 0.6)" } : {}}
                    >
                      {idx + 1}
                    </span>
                  </td>
                  <td className="py-3.5 px-2">
                    <div className="flex items-center gap-3">
                      <TeamLogo teamId={row.id} size={36} />
                      <div className="min-w-0">
                        <div className="font-semibold text-foreground truncate">{team.name}</div>
                        <div className="text-xs text-muted-foreground">{team.short}</div>
                      </div>
                    </div>
                  </td>
                  <td className="text-center py-3.5 px-2 tabular-nums text-foreground/80">{row.played}</td>
                  <td className="text-center py-3.5 px-2 tabular-nums font-semibold text-foreground">{row.won}</td>
                  <td className="text-center py-3.5 px-2 tabular-nums text-muted-foreground">{row.lost}</td>
                  <td className="text-center py-3.5 px-2 tabular-nums">
                    <span
                      className={`inline-flex items-center gap-1 font-medium ${
                        row.nrr >= 0 ? "text-qualify-foreground" : "text-destructive"
                      }`}
                    >
                      {row.nrr >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {row.nrr >= 0 ? "+" : ""}
                      {row.nrr.toFixed(2)}
                    </span>
                  </td>
                  <td className="text-right py-3.5 pr-6 pl-2">
                    <span
                      className="inline-flex items-center justify-center min-w-[2.5rem] px-2.5 py-1 rounded-lg font-bold tabular-nums"
                      style={{
                        background: inTop4 ? "var(--gradient-gold)" : "var(--muted)",
                        color: inTop4 ? "var(--gold-foreground)" : "var(--foreground)",
                        boxShadow: inTop4 ? "var(--shadow-gold)" : "none",
                      }}
                    >
                      {row.points}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="px-6 py-3 bg-muted/30 border-t border-border/60 text-xs text-muted-foreground flex items-center justify-between">
        <span>Top 4 qualify for the Playoffs</span>
        <span className="tabular-nums">{Object.values(predictions).filter(Boolean).length} predictions made</span>
      </div>
    </div>
  );
}
