import { Calendar, Lock, MapPin, RotateCcw, Sparkles } from "lucide-react";
import { TeamLogo } from "./TeamLogo";
import { TEAMS, type Match } from "@/lib/ipl-data";
import { Button } from "@/components/ui/button";

interface MatchScheduleProps {
  matches: Match[];
  predictions: Record<number, string | null>;
  todayISO: string;
  onPredict: (matchId: number, teamId: string) => void;
  onReset: () => void;
}

function formatDate(iso: string) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

export function MatchSchedule({ matches, predictions, todayISO, onPredict, onReset }: MatchScheduleProps) {
  return (
    <div className="rounded-2xl bg-card overflow-hidden flex flex-col h-full" style={{ boxShadow: "var(--shadow-premium)" }}>
      <div
        className="px-5 py-5 flex items-center justify-between"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl flex items-center justify-center bg-white/10 backdrop-blur">
            <Calendar className="h-5 w-5 text-navy-foreground" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight text-navy-foreground">Match Schedule</h2>
            <p className="text-xs text-navy-foreground/70">Predict winners to update standings</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onReset}
          className="text-navy-foreground hover:bg-white/15 hover:text-navy-foreground gap-1.5"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[calc(100vh-12rem)]">
        {matches.map((m) => {
          const isPast = m.date < todayISO;
          const isToday = m.date === todayISO;
          const winner = predictions[m.id] ?? null;
          const locked = isPast && !!winner; // past matches once predicted are locked

          return (
            <MatchCard
              key={m.id}
              match={m}
              winner={winner}
              isToday={isToday}
              isPast={isPast}
              locked={locked}
              onPick={(team) => !locked && onPredict(m.id, team)}
            />
          );
        })}
      </div>
    </div>
  );
}

interface MatchCardProps {
  match: Match;
  winner: string | null;
  isToday: boolean;
  isPast: boolean;
  locked: boolean;
  onPick: (team: string) => void;
}

function MatchCard({ match, winner, isToday, isPast, locked, onPick }: MatchCardProps) {
  return (
    <div
      className="rounded-xl border border-border bg-card p-4 transition-all hover:border-vibrant/40 relative overflow-hidden"
      style={{ boxShadow: "var(--shadow-card)" }}
    >
      {isToday && (
        <div
          className="absolute top-0 right-0 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-bl-lg flex items-center gap-1"
          style={{ background: "var(--gradient-gold)", color: "var(--gold-foreground)" }}
        >
          <Sparkles className="h-3 w-3" />
          Today
        </div>
      )}

      <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
        <span className="font-medium">{formatDate(match.date)} • {match.time}</span>
        {locked && (
          <span className="flex items-center gap-1 text-muted-foreground/80">
            <Lock className="h-3 w-3" /> Locked
          </span>
        )}
      </div>

      <div className="flex items-center gap-1 text-[11px] text-muted-foreground mb-3">
        <MapPin className="h-3 w-3" />
        <span className="truncate">{match.venue}</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <TeamButton team={match.home} selected={winner === match.home} disabled={locked} onClick={() => onPick(match.home)} />
        <TeamButton team={match.away} selected={winner === match.away} disabled={locked} onClick={() => onPick(match.away)} />
      </div>

      {winner && (
        <div className="mt-2.5 text-[11px] text-center text-muted-foreground">
          Winner: <span className="font-semibold text-foreground">{TEAMS[winner].name}</span>
          {isPast && " • Result locked"}
        </div>
      )}
    </div>
  );
}

interface TeamButtonProps {
  team: string;
  selected: boolean;
  disabled: boolean;
  onClick: () => void;
}

function TeamButton({ team, selected, disabled, onClick }: TeamButtonProps) {
  const t = TEAMS[team];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`group relative flex items-center gap-2.5 px-3 py-2.5 rounded-lg border transition-all duration-200 ${
        selected
          ? "border-transparent text-white scale-[1.02]"
          : "border-border bg-muted/40 hover:bg-muted hover:border-vibrant/30 text-foreground"
      } ${disabled ? "cursor-not-allowed opacity-90" : "cursor-pointer active:scale-[0.98]"}`}
      style={
        selected
          ? {
              background: `linear-gradient(135deg, ${t.color} 0%, ${t.color}dd 100%)`,
              boxShadow: `0 8px 20px -8px ${t.color}99, 0 0 0 1px ${t.color}33`,
            }
          : {}
      }
    >
      <TeamLogo teamId={team} size={28} className={selected ? "ring-white/40" : ""} />
      <div className="flex-1 text-left min-w-0">
        <div className={`text-xs font-bold leading-tight ${selected ? "text-white" : "text-foreground"}`}>{t.short}</div>
        <div className={`text-[10px] leading-tight truncate ${selected ? "text-white/80" : "text-muted-foreground"}`}>
          {selected ? "Predicted Winner" : "Pick to win"}
        </div>
      </div>
    </button>
  );
}
