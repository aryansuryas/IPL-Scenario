export interface Team {
  id: string;
  name: string;
  short: string;
  color: string; // tailwind-friendly hex for accent
}

export const TEAMS: Record<string, Team> = {
  MI:   { id: "MI",   name: "Mumbai Indians",          short: "MI",   color: "#045093" },
  CSK:  { id: "CSK",  name: "Chennai Super Kings",     short: "CSK",  color: "#F9CD05" },
  RCB:  { id: "RCB",  name: "Royal Challengers Bengaluru", short: "RCB", color: "#D6172A" },
  KKR:  { id: "KKR",  name: "Kolkata Knight Riders",   short: "KKR",  color: "#3A225D" },
  GT:   { id: "GT",   name: "Gujarat Titans",          short: "GT",   color: "#1B2133" },
  LSG:  { id: "LSG",  name: "Lucknow Super Giants",    short: "LSG",  color: "#0DC0EE" },
  RR:   { id: "RR",   name: "Rajasthan Royals",        short: "RR",   color: "#E91E94" },
  PBKS: { id: "PBKS", name: "Punjab Kings",            short: "PBKS", color: "#DD1F2D" },
  DC:   { id: "DC",   name: "Delhi Capitals",          short: "DC",   color: "#17449B" },
  SRH:  { id: "SRH",  name: "Sunrisers Hyderabad",     short: "SRH",  color: "#FB643E" },
};

export interface Match {
  id: number;
  date: string; // ISO yyyy-mm-dd
  time: string;
  venue: string;
  home: string;
  away: string;
}

// Today is May 14, 2026 per system. Past matches are locked.
export const MATCHES: Match[] = [
  { id: 1,  date: "2026-05-08", time: "19:30", venue: "Wankhede, Mumbai",      home: "MI",   away: "CSK"  },
  { id: 2,  date: "2026-05-09", time: "15:30", venue: "Eden Gardens, Kolkata", home: "KKR",  away: "RCB"  },
  { id: 3,  date: "2026-05-10", time: "19:30", venue: "Narendra Modi, Ahmedabad", home: "GT", away: "PBKS" },
  { id: 4,  date: "2026-05-11", time: "19:30", venue: "Ekana, Lucknow",        home: "LSG",  away: "SRH"  },
  { id: 5,  date: "2026-05-12", time: "19:30", venue: "Sawai Mansingh, Jaipur", home: "RR",  away: "DC"   },
  { id: 6,  date: "2026-05-13", time: "19:30", venue: "Chinnaswamy, Bengaluru", home: "RCB", away: "CSK"  },
  { id: 7,  date: "2026-05-14", time: "19:30", venue: "Wankhede, Mumbai",      home: "MI",   away: "GT"   },
  { id: 8,  date: "2026-05-15", time: "19:30", venue: "Arun Jaitley, Delhi",   home: "DC",   away: "KKR"  },
  { id: 9,  date: "2026-05-16", time: "15:30", venue: "Mullanpur, Mohali",     home: "PBKS", away: "LSG"  },
  { id: 10, date: "2026-05-17", time: "19:30", venue: "Rajiv Gandhi, Hyderabad", home: "SRH", away: "RR"  },
  { id: 11, date: "2026-05-18", time: "19:30", venue: "Eden Gardens, Kolkata", home: "KKR",  away: "MI"   },
  { id: 12, date: "2026-05-19", time: "19:30", venue: "Chepauk, Chennai",      home: "CSK",  away: "GT"   },
  { id: 13, date: "2026-05-20", time: "19:30", venue: "Chinnaswamy, Bengaluru", home: "RCB", away: "PBKS" },
  { id: 14, date: "2026-05-21", time: "19:30", venue: "Ekana, Lucknow",        home: "LSG",  away: "DC"   },
  { id: 15, date: "2026-05-22", time: "19:30", venue: "Sawai Mansingh, Jaipur", home: "RR",  away: "SRH"  },
];

// Pre-tournament base standings (mid-season starting point – simulated)
export interface BaseStat {
  played: number;
  won: number;
  lost: number;
  nrr: number;
}

export const BASE_STATS: Record<string, BaseStat> = {
  GT:   { played: 10, won: 7, lost: 3, nrr:  0.78 },
  RCB:  { played: 10, won: 7, lost: 3, nrr:  0.42 },
  MI:   { played: 10, won: 6, lost: 4, nrr:  1.15 },
  CSK:  { played: 10, won: 6, lost: 4, nrr:  0.32 },
  KKR:  { played: 10, won: 5, lost: 5, nrr:  0.05 },
  LSG:  { played: 10, won: 5, lost: 5, nrr: -0.12 },
  PBKS: { played: 10, won: 4, lost: 6, nrr: -0.24 },
  DC:   { played: 10, won: 4, lost: 6, nrr: -0.41 },
  SRH:  { played: 10, won: 3, lost: 7, nrr: -0.68 },
  RR:   { played: 10, won: 3, lost: 7, nrr: -1.05 },
};
