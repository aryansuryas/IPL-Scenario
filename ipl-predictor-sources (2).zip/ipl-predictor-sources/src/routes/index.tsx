import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Trophy } from "lucide-react";
import { PointsTable } from "@/components/PointsTable";
import { MatchSchedule } from "@/components/MatchSchedule";
import { MATCHES } from "@/lib/ipl-data";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "IPL Points Table Predictor 2026" },
      { name: "description", content: "Predict IPL match winners and watch the points table update live. Premium interactive simulator." },
    ],
  }),
});

const TODAY = "2026-05-14";

function Index() {
  const [predictions, setPredictions] = useState<Record<number, string | null>>({});

  const handlePredict = (matchId: number, teamId: string) => {
    setPredictions((prev) => ({ ...prev, [matchId]: prev[matchId] === teamId ? null : teamId }));
  };

  const handleReset = () => setPredictions({});

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-30 backdrop-blur-md bg-background/80 border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="h-10 w-10 rounded-xl flex items-center justify-center"
              style={{ background: "var(--gradient-hero)", boxShadow: "var(--shadow-premium)" }}
            >
              <Trophy className="h-5 w-5 text-navy-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">IPL Predictor <span className="text-vibrant">2026</span></h1>
              <p className="text-xs text-muted-foreground">Senior-grade points table simulator</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted">
            <div className="h-2 w-2 rounded-full bg-vibrant animate-pulse" />
            <span className="text-xs font-medium text-muted-foreground">Live • Mid-season</span>
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3">
            <PointsTable matches={MATCHES} predictions={predictions} />
          </div>
          <div className="lg:col-span-2">
            <MatchSchedule
              matches={MATCHES}
              predictions={predictions}
              todayISO={TODAY}
              onPredict={handlePredict}
              onReset={handleReset}
            />
          </div>
        </div>

        <footer className="mt-8 text-center text-xs text-muted-foreground">
          Past matches lock once predicted • Today &amp; upcoming matches stay editable
        </footer>
      </main>
    </div>
  );
}
